﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_Bala
{
    public partial class Form1 : Form
    {
        double raio, altura, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            resultado = Math.PI * Math.Pow(raio, 2) * altura;
            txtResultado.Text = resultado.ToString();
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("altura inválida");
                e.Cancel = true;
            }
            else if (altura <= 0) 
            {
                MessageBox.Show("altura deve ser maior que zero");
                e.Cancel = true;
            }


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("raio inválido");
                txtRaio.Focus();
            }
            else if (raio <= 0)
            {
                MessageBox.Show("raio deve ser maior que zero");
                txtRaio.Focus();
            }
                }
    }
}
