﻿namespace Projeto5
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTexto1 = new Label();
            lblTexto2 = new Label();
            txtTexto1 = new TextBox();
            txtTexto2 = new TextBox();
            btnComparar = new Button();
            pictureBox1 = new PictureBox();
            btnInserirMeio = new Button();
            btnInserirSinal = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblTexto1
            // 
            lblTexto1.AutoSize = true;
            lblTexto1.Location = new Point(153, 86);
            lblTexto1.Name = "lblTexto1";
            lblTexto1.Size = new Size(57, 20);
            lblTexto1.TabIndex = 0;
            lblTexto1.Text = "Texto 1";
            lblTexto1.Click += label1_Click;
            // 
            // lblTexto2
            // 
            lblTexto2.AutoSize = true;
            lblTexto2.Location = new Point(153, 218);
            lblTexto2.Name = "lblTexto2";
            lblTexto2.Size = new Size(57, 20);
            lblTexto2.TabIndex = 1;
            lblTexto2.Text = "Texto 2";
            // 
            // txtTexto1
            // 
            txtTexto1.Location = new Point(264, 83);
            txtTexto1.Name = "txtTexto1";
            txtTexto1.Size = new Size(192, 27);
            txtTexto1.TabIndex = 2;
            // 
            // txtTexto2
            // 
            txtTexto2.Location = new Point(264, 211);
            txtTexto2.Name = "txtTexto2";
            txtTexto2.Size = new Size(192, 27);
            txtTexto2.TabIndex = 3;
            // 
            // btnComparar
            // 
            btnComparar.Location = new Point(96, 317);
            btnComparar.Name = "btnComparar";
            btnComparar.Size = new Size(189, 52);
            btnComparar.TabIndex = 4;
            btnComparar.Text = "Comparar Textos";
            btnComparar.UseVisualStyleBackColor = true;
            btnComparar.Click += btnComparar_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.images;
            pictureBox1.Location = new Point(501, 66);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(270, 186);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // btnInserirMeio
            // 
            btnInserirMeio.Location = new Point(318, 314);
            btnInserirMeio.Name = "btnInserirMeio";
            btnInserirMeio.Size = new Size(198, 55);
            btnInserirMeio.TabIndex = 6;
            btnInserirMeio.Text = "Inserir Texto 1 no meio do Texto 2";
            btnInserirMeio.UseVisualStyleBackColor = true;
            btnInserirMeio.Click += button1_Click;
            // 
            // btnInserirSinal
            // 
            btnInserirSinal.Location = new Point(566, 314);
            btnInserirSinal.Name = "btnInserirSinal";
            btnInserirSinal.Size = new Size(178, 52);
            btnInserirSinal.TabIndex = 7;
            btnInserirSinal.Text = "Inserir 2 * no meio do Texto 1";
            btnInserirSinal.UseVisualStyleBackColor = true;
            btnInserirSinal.Click += btnInserirSinal_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInserirSinal);
            Controls.Add(btnInserirMeio);
            Controls.Add(pictureBox1);
            Controls.Add(btnComparar);
            Controls.Add(txtTexto2);
            Controls.Add(txtTexto1);
            Controls.Add(lblTexto2);
            Controls.Add(lblTexto1);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTexto1;
        private Label lblTexto2;
        private TextBox txtTexto1;
        private TextBox txtTexto2;
        private Button btnComparar;
        private PictureBox pictureBox1;
        private Button btnInserirMeio;
        private Button btnInserirSinal;
    }
}