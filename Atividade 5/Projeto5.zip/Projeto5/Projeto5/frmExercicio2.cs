﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto5
{
    public partial class frmExercicio2 : Form
    {
        string Texto1;
        string Texto2;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            Texto1 = txtTexto1.Text;
            Texto2 = txtTexto2.Text;

            if (String.Compare(Texto1, Texto2) == 0)
            {
                MessageBox.Show("Os Textos são Iguais");
            }
            else
            {
                MessageBox.Show("Os Textos são Diferentes");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Texto1 = txtTexto1.Text;
            Texto2 = txtTexto2.Text;
            string primeiraparte;
            string segundaparte;

            int metade = Texto2.Length / 2;
            primeiraparte = Texto2.Substring(0, metade);
            segundaparte = Texto2.Substring(metade);

            txtTexto2.Text = primeiraparte + Texto1 + segundaparte;

        }

        private void btnInserirSinal_Click(object sender, EventArgs e)
        {
            Texto1 = txtTexto1.Text;
            Texto2 = txtTexto2.Text;
            

            int metade = Texto1.Length / 2;

            txtTexto2.Text = Texto1.Insert(metade, "**");
        }
    }
}
