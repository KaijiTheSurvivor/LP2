﻿namespace Projeto5
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtTexto1 = new TextBox();
            btnReverter = new Button();
            btnRemover = new Button();
            txtTexto2 = new TextBox();
            lblTexto1 = new Label();
            lblTexto2 = new Label();
            SuspendLayout();
            // 
            // txtTexto1
            // 
            txtTexto1.Location = new Point(267, 139);
            txtTexto1.Name = "txtTexto1";
            txtTexto1.Size = new Size(462, 27);
            txtTexto1.TabIndex = 0;
            // 
            // btnReverter
            // 
            btnReverter.Location = new Point(582, 422);
            btnReverter.Name = "btnReverter";
            btnReverter.Size = new Size(147, 62);
            btnReverter.TabIndex = 1;
            btnReverter.Text = "Reverter";
            btnReverter.UseVisualStyleBackColor = true;
            btnReverter.Click += btnReverter_Click;
            // 
            // btnRemover
            // 
            btnRemover.Location = new Point(267, 422);
            btnRemover.Name = "btnRemover";
            btnRemover.Size = new Size(139, 62);
            btnRemover.TabIndex = 2;
            btnRemover.Text = "Remover";
            btnRemover.UseVisualStyleBackColor = true;
            btnRemover.Click += btnRemover_Click;
            // 
            // txtTexto2
            // 
            txtTexto2.Location = new Point(267, 290);
            txtTexto2.Name = "txtTexto2";
            txtTexto2.Size = new Size(462, 27);
            txtTexto2.TabIndex = 3;
            // 
            // lblTexto1
            // 
            lblTexto1.AutoSize = true;
            lblTexto1.Location = new Point(161, 297);
            lblTexto1.Name = "lblTexto1";
            lblTexto1.Size = new Size(53, 20);
            lblTexto1.TabIndex = 4;
            lblTexto1.Text = "Texto2";
            // 
            // lblTexto2
            // 
            lblTexto2.AutoSize = true;
            lblTexto2.Location = new Point(158, 142);
            lblTexto2.Name = "lblTexto2";
            lblTexto2.Size = new Size(53, 20);
            lblTexto2.TabIndex = 5;
            lblTexto2.Text = "Texto1";
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1007, 632);
            Controls.Add(lblTexto2);
            Controls.Add(lblTexto1);
            Controls.Add(txtTexto2);
            Controls.Add(btnRemover);
            Controls.Add(btnReverter);
            Controls.Add(txtTexto1);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            Load += frmExercicio3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtTexto1;
        private Button btnReverter;
        private Button btnRemover;
        private TextBox txtTexto2;
        private Label lblTexto1;
        private Label lblTexto2;
    }
}