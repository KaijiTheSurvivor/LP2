﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto5
{
    public partial class frmExercicio3 : Form
    {
        string texto1;
        string texto2;
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void frmExercicio3_Load(object sender, EventArgs e)
        {

        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            texto1 = txtTexto1.Text;
            texto2 = txtTexto2.Text;

            txtTexto2.Text = texto2.Replace(texto1, "");
        }

        private void btnReverter_Click(object sender, EventArgs e)
        {
            texto1 = txtTexto1.Text;
            texto2 = txtTexto2.Text;

           char[] original = texto1.ToCharArray();
            Array.Reverse(original);

            texto1 = new string(original);

            MessageBox.Show(texto1);

        }
    }
}
