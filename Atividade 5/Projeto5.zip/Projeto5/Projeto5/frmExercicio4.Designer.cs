﻿namespace Projeto5
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rtxTexto1 = new RichTextBox();
            btnContaNumero = new Button();
            btnContaLetra = new Button();
            btnBranco = new Button();
            lblTexto1 = new Label();
            SuspendLayout();
            // 
            // rtxTexto1
            // 
            rtxTexto1.Location = new Point(190, 61);
            rtxTexto1.Name = "rtxTexto1";
            rtxTexto1.Size = new Size(513, 120);
            rtxTexto1.TabIndex = 0;
            rtxTexto1.Text = "";
            // 
            // btnContaNumero
            // 
            btnContaNumero.Location = new Point(227, 346);
            btnContaNumero.Name = "btnContaNumero";
            btnContaNumero.Size = new Size(132, 102);
            btnContaNumero.TabIndex = 1;
            btnContaNumero.Text = "Quantidade de caracteres numericos";
            btnContaNumero.UseVisualStyleBackColor = true;
            btnContaNumero.Click += btnContaNumero_Click;
            // 
            // btnContaLetra
            // 
            btnContaLetra.Location = new Point(547, 346);
            btnContaLetra.Name = "btnContaLetra";
            btnContaLetra.Size = new Size(123, 102);
            btnContaLetra.TabIndex = 2;
            btnContaLetra.Text = "Quantidade de caracteres alfabeticos";
            btnContaLetra.UseVisualStyleBackColor = true;
            btnContaLetra.Click += btnContaLetra_Click;
            // 
            // btnBranco
            // 
            btnBranco.Location = new Point(388, 346);
            btnBranco.Name = "btnBranco";
            btnBranco.Size = new Size(126, 102);
            btnBranco.TabIndex = 3;
            btnBranco.Text = "Posição do primeiro espaço";
            btnBranco.UseVisualStyleBackColor = true;
            btnBranco.Click += button3_Click;
            // 
            // lblTexto1
            // 
            lblTexto1.AutoSize = true;
            lblTexto1.Location = new Point(72, 111);
            lblTexto1.Name = "lblTexto1";
            lblTexto1.Size = new Size(45, 20);
            lblTexto1.TabIndex = 4;
            lblTexto1.Text = "Texto";
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(936, 555);
            Controls.Add(lblTexto1);
            Controls.Add(btnBranco);
            Controls.Add(btnContaLetra);
            Controls.Add(btnContaNumero);
            Controls.Add(rtxTexto1);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox rtxTexto1;
        private Button btnContaNumero;
        private Button btnContaLetra;
        private Button btnBranco;
        private Label lblTexto1;
    }
}