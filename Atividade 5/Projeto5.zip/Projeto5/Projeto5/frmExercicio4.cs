﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto5
{
    public partial class frmExercicio4 : Form
    {
        string texto1;
        int i = 0;
        int contador = 0;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int numero = 0;
            texto1 = rtxTexto1.Text;
            for (int i = 0; i < texto1.Length; i++)
            {
                if (char.IsWhiteSpace(texto1[i]))
                {
                    numero = i;
                }

            }
            if (numero != 0)
            {
                MessageBox.Show($"A posição do primeiro espaço é {numero + 1}");
            }
            else
                MessageBox.Show("Não existe espaços nesse texto!");
        }

        private void btnContaNumero_Click(object sender, EventArgs e)
        {
            texto1 = rtxTexto1.Text;

            do
            {
                if (char.IsNumber(texto1[i]))
                {
                    contador++;
                    i++;
                }
                else
                {
                    i++;
                }
            }
            while (i < texto1.Length);
            MessageBox.Show($"Quantidade de caracteres numericos é {contador}");
            contador = 0;
            





        }

        private void btnContaLetra_Click(object sender, EventArgs e)
        {
            texto1 = rtxTexto1.Text;

            foreach(char c in texto1)
            {
                if (char.IsLetter(c))
                contador++;
            }
            MessageBox.Show($"Quantidade de caracteres alfabeticos é {contador}");
            contador = 0;
        }
    }
}
