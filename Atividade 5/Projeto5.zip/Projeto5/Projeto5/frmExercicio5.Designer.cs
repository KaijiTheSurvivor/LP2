﻿namespace Projeto5
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            btnSortear = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(337, 78);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(102, 27);
            txtNumero1.TabIndex = 0;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(337, 156);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(102, 27);
            txtNumero2.TabIndex = 1;
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(189, 85);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(75, 20);
            lblNumero1.TabIndex = 2;
            lblNumero1.Text = "Numero 1";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(189, 163);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(75, 20);
            lblNumero2.TabIndex = 3;
            lblNumero2.Text = "Numero 2";
            // 
            // btnSortear
            // 
            btnSortear.Location = new Point(312, 282);
            btnSortear.Name = "btnSortear";
            btnSortear.Size = new Size(140, 47);
            btnSortear.TabIndex = 4;
            btnSortear.Text = "Sortear";
            btnSortear.UseVisualStyleBackColor = true;
            btnSortear.Click += btnSortear_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImageLayout = ImageLayout.Center;
            pictureBox1.Image = Properties.Resources.Jogo_on_line_tigrinho_1024x1024;
            pictureBox1.Location = new Point(498, 39);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(270, 248);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(btnSortear);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private Label lblNumero1;
        private Label lblNumero2;
        private Button btnSortear;
        private PictureBox pictureBox1;
    }
}