﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblNumero1 = new Label();
            lblResultado = new Label();
            lblNumero2 = new Label();
            txtNumero1 = new TextBox();
            txtResultado = new TextBox();
            txtNumero2 = new TextBox();
            btnLimpar = new Button();
            btnSair = new Button();
            btnSub = new Button();
            btnAdd = new Button();
            btnDiv = new Button();
            btnMult = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider3 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).BeginInit();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(202, 115);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(92, 25);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Número 1";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(202, 405);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(90, 25);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Resultado";
            lblResultado.Click += label2_Click;
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(202, 262);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(92, 25);
            lblNumero2.TabIndex = 2;
            lblNumero2.Text = "Número 2";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(446, 109);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(337, 31);
            txtNumero1.TabIndex = 3;
            txtNumero1.TextChanged += txtNumero1_TextChanged;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // txtResultado
            // 
            txtResultado.Enabled = false;
            txtResultado.Location = new Point(446, 399);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(337, 31);
            txtResultado.TabIndex = 4;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(446, 256);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(337, 31);
            txtNumero2.TabIndex = 5;
            txtNumero2.TextChanged += textBox3_TextChanged;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(907, 99);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(217, 101);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(907, 319);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(217, 111);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += button3_Click;
            // 
            // btnSub
            // 
            btnSub.Font = new Font("Segoe UI", 11F);
            btnSub.Location = new Point(426, 501);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(149, 59);
            btnSub.TabIndex = 9;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 11F);
            btnAdd.Location = new Point(202, 501);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(147, 59);
            btnAdd.TabIndex = 10;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDiv
            // 
            btnDiv.Font = new Font("Segoe UI", 11F);
            btnDiv.Location = new Point(849, 501);
            btnDiv.Name = "btnDiv";
            btnDiv.RightToLeft = RightToLeft.No;
            btnDiv.Size = new Size(142, 59);
            btnDiv.TabIndex = 11;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += button6_Click;
            // 
            // btnMult
            // 
            btnMult.Font = new Font("Segoe UI", 11F);
            btnMult.Location = new Point(658, 501);
            btnMult.Name = "btnMult";
            btnMult.Size = new Size(135, 59);
            btnMult.TabIndex = 12;
            btnMult.Text = "*";
            btnMult.UseVisualStyleBackColor = true;
            btnMult.Click += btnMult_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider3
            // 
            errorProvider3.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1245, 705);
            Controls.Add(btnMult);
            Controls.Add(btnDiv);
            Controls.Add(btnAdd);
            Controls.Add(btnSub);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtNumero2);
            Controls.Add(txtResultado);
            Controls.Add(txtNumero1);
            Controls.Add(lblNumero2);
            Controls.Add(lblResultado);
            Controls.Add(lblNumero1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblResultado;
        private Label lblNumero2;
        private TextBox txtNumero1;
        private TextBox txtResultado;
        private TextBox txtNumero2;
        private Button btnLimpar;
        private Button btnSair;
        private Button btnSub;
        private Button btnAdd;
        private Button btnDiv;
        private Button btnMult;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider3;
    }
}
