namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtResultado.Clear();

            if (!Double.TryParse(txtNumero1.Text, out numero1) || !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                if (numero2 == 0)
                    errorProvider3.SetError(txtNumero2, "N�o dividir�s por 0");
                else
                {
                    resultado = numero1 / numero2;
                    txtResultado.Text = resultado.ToString();
                    errorProvider3.SetError(txtNumero2, "");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voc� deseja sair mesmo ?","Sa�da", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
               
        }


        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero1, "N�mero 1 inv�lido");
            }
            else
                errorProvider1.SetError(txtNumero1, "");
        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider3.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch (Exception)
            {
                errorProvider3.SetError(txtNumero2, "Numero 2 Invalido");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtResultado.Clear();

            if (!Double.TryParse(txtNumero1.Text, out numero1) || !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            txtResultado.Clear();

            if (!Double.TryParse(txtNumero1.Text, out numero1) || !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            txtResultado.Clear();

            if (!Double.TryParse(txtNumero1.Text, out numero1) || !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }
    }
}
