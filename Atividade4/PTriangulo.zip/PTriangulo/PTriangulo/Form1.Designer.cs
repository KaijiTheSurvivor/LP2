﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblLadoA = new Label();
            lblLadoC = new Label();
            lblLadoB = new Label();
            txtLadoA = new TextBox();
            txtLadoB = new TextBox();
            txtLadoC = new TextBox();
            btnExecutar = new Button();
            btnSair = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Location = new Point(157, 119);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(93, 25);
            lblLadoA.TabIndex = 0;
            lblLadoA.Text = "Lado de A";
            lblLadoA.Click += label1_Click;
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Location = new Point(158, 389);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(92, 25);
            lblLadoC.TabIndex = 1;
            lblLadoC.Text = "Lado de C";
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Location = new Point(157, 261);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(91, 25);
            lblLadoB.TabIndex = 2;
            lblLadoB.Text = "Lado de B";
            // 
            // txtLadoA
            // 
            txtLadoA.Location = new Point(388, 119);
            txtLadoA.Name = "txtLadoA";
            txtLadoA.Size = new Size(195, 31);
            txtLadoA.TabIndex = 3;
            txtLadoA.Validated += txtLadoA_Validated;
            // 
            // txtLadoB
            // 
            txtLadoB.Location = new Point(388, 261);
            txtLadoB.Name = "txtLadoB";
            txtLadoB.Size = new Size(195, 31);
            txtLadoB.TabIndex = 4;
            txtLadoB.Validated += txtLadoB_Validated;
            // 
            // txtLadoC
            // 
            txtLadoC.Location = new Point(388, 389);
            txtLadoC.Name = "txtLadoC";
            txtLadoC.Size = new Size(195, 31);
            txtLadoC.TabIndex = 5;
            txtLadoC.TextChanged += textBox3_TextChanged;
            txtLadoC.Validated += txtLadoC_Validated;
            // 
            // btnExecutar
            // 
            btnExecutar.Location = new Point(226, 533);
            btnExecutar.Name = "btnExecutar";
            btnExecutar.Size = new Size(124, 48);
            btnExecutar.TabIndex = 6;
            btnExecutar.Text = "Executar";
            btnExecutar.UseVisualStyleBackColor = true;
            btnExecutar.Click += btnExecutar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(471, 533);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(122, 48);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = (Image)resources.GetObject("pictureBox1.InitialImage");
            pictureBox1.Location = new Point(733, 132);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(382, 337);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            pictureBox1.UseWaitCursor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1184, 678);
            Controls.Add(pictureBox1);
            Controls.Add(btnSair);
            Controls.Add(btnExecutar);
            Controls.Add(txtLadoC);
            Controls.Add(txtLadoB);
            Controls.Add(txtLadoA);
            Controls.Add(lblLadoB);
            Controls.Add(lblLadoC);
            Controls.Add(lblLadoA);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLadoA;
        private Label lblLadoC;
        private Label lblLadoB;
        private TextBox txtLadoA;
        private TextBox txtLadoB;
        private TextBox txtLadoC;
        private Button btnExecutar;
        private Button btnSair;
        private PictureBox pictureBox1;
    }
}
