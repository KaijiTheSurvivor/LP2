namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                txtLadoA.Clear();
                MessageBox.Show("Lado A Invalido");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                txtLadoB.Clear();
                MessageBox.Show("Lado B Invalido");
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                txtLadoC.Clear();
                MessageBox.Show("Lado C Invalido");
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (ladoA > Math.Abs(ladoB - ladoC) && ladoA < ladoB + ladoC
                && ladoB > Math.Abs(ladoA - ladoC) && ladoB < ladoA + ladoC &&
                ladoC > Math.Abs(ladoA - ladoB) && ladoC < ladoA + ladoB && ladoA != 0
                && ladoB != 0 && ladoC != 0)
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Seu Triangulo � Equilatero ");
                }
                else if (ladoA == ladoB || ladoB == ladoC || ladoC == ladoA)
                {
                    MessageBox.Show("Seu Triangulo � Isosceles ");
                }
                else
                {
                    MessageBox.Show("Seu Triangulo � Escaleno");
                }
            }
            else
            {
                txtLadoA.Clear();
                txtLadoB.Clear();
                txtLadoC.Clear();
                MessageBox.Show("Triangulo Impossivel");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
