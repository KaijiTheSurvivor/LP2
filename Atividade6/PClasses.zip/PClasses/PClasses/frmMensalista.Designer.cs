﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMA = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSM = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.lblMa = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSM = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.btnIM = new System.Windows.Forms.Button();
            this.btnINP = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtMA
            // 
            this.txtMA.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMA.Location = new System.Drawing.Point(507, 168);
            this.txtMA.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMA.Name = "txtMA";
            this.txtMA.Size = new System.Drawing.Size(133, 35);
            this.txtMA.TabIndex = 0;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(507, 208);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(388, 35);
            this.txtNome.TabIndex = 1;
            // 
            // txtSM
            // 
            this.txtSM.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSM.Location = new System.Drawing.Point(507, 248);
            this.txtSM.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSM.Name = "txtSM";
            this.txtSM.Size = new System.Drawing.Size(308, 35);
            this.txtSM.TabIndex = 2;
            // 
            // txtData
            // 
            this.txtData.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData.Location = new System.Drawing.Point(507, 288);
            this.txtData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(308, 35);
            this.txtData.TabIndex = 3;
            // 
            // lblMa
            // 
            this.lblMa.AutoSize = true;
            this.lblMa.BackColor = System.Drawing.Color.RosyBrown;
            this.lblMa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblMa.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMa.Location = new System.Drawing.Point(108, 171);
            this.lblMa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(121, 28);
            this.lblMa.TabIndex = 4;
            this.lblMa.Text = "Matricula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.RosyBrown;
            this.lblNome.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblNome.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(108, 217);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(79, 28);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome";
            // 
            // lblSM
            // 
            this.lblSM.AutoSize = true;
            this.lblSM.BackColor = System.Drawing.Color.RosyBrown;
            this.lblSM.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblSM.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSM.Location = new System.Drawing.Point(108, 257);
            this.lblSM.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSM.Name = "lblSM";
            this.lblSM.Size = new System.Drawing.Size(183, 28);
            this.lblSM.TabIndex = 6;
            this.lblSM.Text = "Salário Mensal";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.BackColor = System.Drawing.Color.RosyBrown;
            this.lblData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblData.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.Location = new System.Drawing.Point(108, 297);
            this.lblData.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(347, 28);
            this.lblData.TabIndex = 7;
            this.lblData.Text = "Data de Entrada Na Empresa";
            // 
            // btnIM
            // 
            this.btnIM.BackColor = System.Drawing.Color.RosyBrown;
            this.btnIM.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIM.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIM.Location = new System.Drawing.Point(210, 460);
            this.btnIM.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnIM.Name = "btnIM";
            this.btnIM.Size = new System.Drawing.Size(262, 85);
            this.btnIM.TabIndex = 8;
            this.btnIM.Text = "Instanciar Mensalista";
            this.btnIM.UseVisualStyleBackColor = false;
            this.btnIM.Click += new System.EventHandler(this.btnIM_Click);
            // 
            // btnINP
            // 
            this.btnINP.BackColor = System.Drawing.Color.RosyBrown;
            this.btnINP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnINP.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnINP.Location = new System.Drawing.Point(507, 460);
            this.btnINP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnINP.Name = "btnINP";
            this.btnINP.Size = new System.Drawing.Size(262, 85);
            this.btnINP.TabIndex = 9;
            this.btnINP.Text = "Intancial Mensalista passando parâmetro";
            this.btnINP.UseVisualStyleBackColor = false;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(939, 692);
            this.Controls.Add(this.btnINP);
            this.Controls.Add(this.btnIM);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblSM);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMa);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtSM);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMA);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.Load += new System.EventHandler(this.frmMensalista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMA;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSM;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSM;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Button btnIM;
        private System.Windows.Forms.Button btnINP;
    }
}