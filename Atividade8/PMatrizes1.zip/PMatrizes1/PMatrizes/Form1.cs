﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Diagnostics;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = null;
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o número {i + 1}º ", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show($"Numero {i + 1}º Invalido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList minhaLista = new ArrayList() { "Caio", "Andre", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcello", "Pedro" };
            minhaLista.Remove("Otávio");
            string auxiliar = "";
            foreach (string nomes in minhaLista)
            {
                auxiliar += nomes + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
            string auxiliar = "";
            Double[] media = new double[20];

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {nota + 1} do aluno {aluno + 1}", "Inserir Notas ");
                    if (auxiliar == "")
                    {
                        break;
                    }
                    else if (!double.TryParse(auxiliar, out notas[aluno, nota]) || notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Numero Invalido");
                        nota--;
                    }

                }
                media[aluno] = (notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2]) / 3;
                MessageBox.Show($"Media do aluno {aluno}: {media[aluno]}");

            }

        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 Obj1 = new frmExercicio4();
            Obj1.Show();
            

        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 Obj1 = new frmExercicio5();
            Obj1.Show();
        }
    }
}
    
