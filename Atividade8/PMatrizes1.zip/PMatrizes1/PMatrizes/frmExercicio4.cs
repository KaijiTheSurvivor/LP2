﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar;
            string[] vetor = new string[10];
            string[] vtfinal = new string[10];
            int[] numletras = new int[10];
            int i, j, cont = 0;
            for (i = 0; i < 10; i++)
            {
                vetor[i] = Interaction.InputBox("Digite seu nome completo : ", $"Inserir nome {i + 1}");
                if (vetor[i] == "")
                    break;
                for (j = 0; j < vetor[i].Length; j++)
                {
                    cont++;
                    if (vetor[i][j] == ' ')
                        cont--;
                }
                numletras[i] = cont;
                cont = 0;
                vtfinal[i] = "o nome " + vetor[i] + " tem " + numletras[i] + "caracteres";
            }
            if (!(vetor[i] == "")) 
                ltbNomes.Items.AddRange(vtfinal);
        }
    }
}
