﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string gabarito = "ACBACDEEAB" ;
            string letras = "ABCDE";
            string[,] respostas = new string[9, 10];
            string[,] final = new string[9,10]; 
            int alunos, questoes = 0;
            for (alunos = 0; alunos < 9; alunos++)
            {
                for (questoes = 0; questoes < 10; questoes++)
                {
                 
                    bool respostaValida = false;
                    while (!respostaValida)
                    {

                        respostas[alunos, questoes] = Interaction.InputBox($"Digite a resposta da questão {questoes + 1} do aluno {alunos + 1}", "Digitar Nota");


                        if (letras.Contains(respostas[alunos, questoes].ToUpper()))
                        {
                            respostaValida = true;
                        }
                        else
                        {
                            MessageBox.Show("Resposta Inválida. Tente novamente.");

                        }
                        if (respostas[alunos, questoes].ToUpper() == gabarito[questoes].ToString())
                        {
                            final[alunos, questoes] = $"O aluno {alunos+1} acertou a questão {questoes+1} : era {gabarito[questoes]} e ele escolheu {respostas[alunos, questoes].ToUpper()}.";
                        }
                        else 
                        {
                            final[alunos, questoes] = $"O aluno {alunos+1} errou a questão {questoes+1} : era {gabarito[questoes]} e ele escolheu {respostas[alunos, questoes].ToUpper()}.";
                        }
                        ltbNotas.Items.Add(final[alunos, questoes]);
                    } 

                  
                }
            }
            ;
        }

        private void ltbNotas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
