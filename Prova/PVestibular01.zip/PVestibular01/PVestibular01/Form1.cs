﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVestibular01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnReceber_Click(object sender, EventArgs e)
        {
            lbxOutput.Items.Clear();
            int[,] qtdAlunos = new int[3, 5];
            String input;
            string[,] respostas = new String[3, 8];
            int[] totalCursos = new int[3];
            int total = 0;
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    input = Interaction.InputBox($"Insira a quantidade de alunos do curso {i + 1} do ano {j + 1}: ");
                    if(!int.TryParse(input, out qtdAlunos[i, j]) || qtdAlunos[i, j] < 0)
                    {
                        MessageBox.Show("Numero Inválido");
                        j--;
                    }


                }
            }
            for (i = 0;i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    totalCursos[i] += qtdAlunos[i, j];

                }
                total += totalCursos[i];
            }
            for (i = 0;i<3; i++)
            {
                for (j = 0;j < 8; j++)
                {
                    if (j < 5)
                    {
                        respostas[i, j] = "Total do curso " + (i + 1) + " do Ano " + (j + 1) + ": " + qtdAlunos[i, j];
                    }
                    else if (j == 5)
                    {
                        respostas[i, j] = "_______________________ ";
                    }
                    else if (j == 6)
                    {
                        respostas[i, j] = "Total curso " + (i+1) + ": " + totalCursos[i];
                    }
                    else if (j == 7)
                    {
                        respostas[i, j] = "_______________________ ";
                    }

                }
            }

            int aux = 0;
            String[] respostasUni = new string[24];
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 8; j++)
                {
                    respostasUni[aux] = respostas[i, j];
                    aux++;
                }
            }
            

            lbxOutput.Items.AddRange(respostasUni);
            lbxOutput.Items.Add($"Total Geral: {total}");

            

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxOutput.Items.Clear();
        }
    }
}
